package org.elias.fascicle.quarkus.book;

import io.quarkus.test.Mock;
import jakarta.enterprise.context.ApplicationScoped;
import org.elias.fascicle.quarkus.book.client.IsbnNumbers;
import org.elias.fascicle.quarkus.book.client.NumberProxy;
import org.eclipse.microprofile.rest.client.inject.RestClient;


@Mock
@ApplicationScoped
@RestClient
public class MockNumberProxy implements NumberProxy {

  @Override
  public IsbnNumbers generateIsbnNumbers() {
    IsbnNumbers isbnNumbers = new IsbnNumbers();

    isbnNumbers.setIsbn13(BookResourceTest.MOCK_ISBN_13);
    isbnNumbers.setIsbn10(BookResourceTest.MOCK_ISBN_10);
    return isbnNumbers;
  }
}
