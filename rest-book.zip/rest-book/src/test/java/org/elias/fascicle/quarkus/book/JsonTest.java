package org.elias.fascicle.quarkus.book;

import io.quarkus.test.junit.QuarkusTest;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import jakarta.json.bind.JsonbException;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class JsonTest {

    @Test
    void testBookDTOSerialization() {
        Jsonb jsonb = JsonbBuilder.create();

        BookDTO bookDTO = new BookDTO();
        bookDTO.setTitle("Harry el sucio 4");
        bookDTO.setRank(4);

        AutorDTO autor = new AutorDTO();
        autor.setNombre("Elias");
        autor.setApellido("Maldonado");

        bookDTO.setAutores(Collections.singletonList(autor));

        try {
            String jsonString = jsonb.toJson(bookDTO);
            System.out.println("Generated JSON:");
            System.out.println(jsonString);

            // Puedes definir aquí el JSON esperado si es necesario para comparación manual
            String expectedJson = "{\"title\":\"Harry el sucio 4\",\"rank\":4,\"autores\":[{\"nombre\":\"Elias\",\"apellido\":\"Maldonado\"}]}";
            System.out.println("Expected JSON:");
            System.out.println(expectedJson);

        } catch (JsonbException e) {
            e.printStackTrace();
        }
    }
}
