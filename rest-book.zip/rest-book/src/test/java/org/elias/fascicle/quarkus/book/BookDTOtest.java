package org.elias.fascicle.quarkus.book;

import io.quarkus.test.Mock;
import io.quarkus.test.common.QuarkusTestResource;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
//import org.mockito.InjectMocks;
import jakarta.inject.*;

import jakarta.persistence.EntityManager;
import jakarta.ws.rs.NotFoundException;

import org.elias.fascicle.quarkus.book.AccesoLibro.*;
import org.elias.fascicle.quarkus.book.ServicioLibro.BookService;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.junit.jupiter.api.TestMethodOrder;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.ArrayList;

import java.util.Optional;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BookDTOtest {

    @Inject
    EntityManager em;

    private CategoriaRepository categoriaRepository;
    private AuthorsRepository authorRepository;
    private BookRepository repository;
    private final BookMapper bookMapper = BookMapper.INSTANCE;

    private BookService bookService;

    private BookDTO bookDTO;
    private Book bookEntity;
    private Categorias category;
    private Autores author;

    @Test
    public void testLibroAlibroDTO() {
        // Simular búsqueda de una categoría existente
        Categorias categoria = buscarCategoriaPorNombre("Ficción");
        if (categoria == null) {
            System.out.println("Categoría no encontrada.");
            return;
        }

        // Simular búsqueda de un autor existente
        Autores autor = buscarAutorPorNombre("John", "Doe");
        if (autor == null) {
            System.out.println("Autor no encontrado.");
            return;
        }

        // Configurar un Book con la categoría y el autor existentes
        Book book = new Book();
        book.setId(1L);
        book.setYearOfPublication(2020);
        book.setNbOfPages(300);
        book.setRank(5);
        book.setDescription("Descripción del libro");
        book.setCategoria(categoria);

        List<Autores> autores = new ArrayList<>();
        autores.add(autor);
        book.setAutores(autores);

        // Convertir Book a BookDTO
        BookDTO bookDTO = bookMapper.LibroAlibroDTO(book);

        // Verificar la conversión
        if (bookDTO != null) {
            System.out.println("ID: " + book.getId() + " -> " + bookDTO.getId());
            System.out.println("Year of Publication: " + book.getYearOfPublication() + " -> " + bookDTO.getYearOfPublication());
            System.out.println("Number of Pages: " + book.getNbOfPages() + " -> " + bookDTO.getNbOfPages());
            System.out.println("Rank: " + book.getRank() + " -> " + bookDTO.getRank());
            System.out.println("Description: " + book.getDescription() + " -> " + bookDTO.getDescription());
            System.out.println("Category Name: " + book.getCategoria().getNombre() + " -> " + bookDTO.getCategoriaNombre());

            List<String> autoresList = book.getAutores().stream().map(Autores::toString).collect(Collectors.toList());
            System.out.println("Authors: " + autoresList + " -> " + bookDTO.getAutoresString());
        } else {
            System.out.println("bookDTO is null");
        }
    }

    // Métodos auxiliares para simular la búsqueda de categoría y autor existentes
    private Categorias buscarCategoriaPorNombre(String nombre) {
        // Simular la búsqueda en el repositorio de categorías
        if ("Ficción".equals(nombre)) {
            Categorias categoria = new Categorias();
            categoria.setNombre("Ficción");
            return categoria;
        }
        return null;
    }

    private Autores buscarAutorPorNombre(String nombre, String apellido) {
        // Simular la búsqueda en el repositorio de autores
        if ("John".equals(nombre) && "Doe".equals(apellido)) {
            Autores autor = new Autores();
            autor.setNombre("John");
            autor.setApellido("Doe");
            return autor;
        }
        return null;
    }
}



/*
    public void testLibroAlibroDTO() {
        // Configurar un Book de prueba
        Book book = new Book();
        book.setId(1L);
        book.setYearOfPublication(2020);
        book.setNbOfPages(300);
        book.setRank(5);
      //  book.setPrice(0);
      //  book.setSmallImageUrl("smallImage.jpg");
      //  book.setMediumImageUrl("mediumImage.jpg");
        book.setDescription("Descripción del libro");

        Categorias categoria = new Categorias();
        categoria.setNombre("Ficción");
        book.setCategoria(categoria);

        Autores autor = new Autores();
        autor.setNombre("John");
        autor.setApellido("Doe");
        List<Autores> autores = new ArrayList<>();
        autores.add(autor);

        book.setAutores(autores);

        // Convertir Book a BookDTO
        BookDTO bookDTO = bookMapper.LibroAlibroDTO(book);

        // Verificar la conversión
        if (bookDTO != null) {
            System.out.println("ID: " + book.getId() + " -> " + bookDTO.getId());
            System.out.println("Year of Publication: " + book.getYearOfPublication() + " -> " + bookDTO.getYearOfPublication());
            System.out.println("Number of Pages: " + book.getNbOfPages() + " -> " + bookDTO.getNbOfPages());
            System.out.println("Rank: " + book.getRank() + " -> " + bookDTO.getRank());
            // System.out.println("Price: " + book.getPrice() + " -> " + bookDTO.getPrice());
            // System.out.println("Small Image URL: " + book.getSmallImageUrl() + " -> " + bookDTO.getSmallImageUrl());
            // System.out.println("Medium Image URL: " + book.getMediumImageUrl() + " -> " + bookDTO.getMediumImageUrl());
            System.out.println("Description: " + book.getDescription() + " -> " + bookDTO.getDescription());
            System.out.println("Category Name: " + book.getCategoria().getNombre() + " -> " + bookDTO.getCategoriaNombre());

            List<String> autoresList = book.getAutores().stream().map(Autores::toString).collect(Collectors.toList());
            System.out.println("Authors: " + autoresList + " -> " + bookDTO.getAutoresString());
        } else {
            System.out.println("bookDTO is null");
        }
    }

 */



