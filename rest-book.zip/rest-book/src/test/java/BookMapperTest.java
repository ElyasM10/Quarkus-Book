import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat;
import java.util.Arrays;
import java.util.List;



public class BookMapperTest {

    private final BookMapper bookMapper = BookMapper.INSTANCE;

    @Test
    public void testMapAutoresAstrings() {
        // Crear un autor de ejemplo
        Autores autor1 = new Autores();
        autor1.setNombre("John");
        autor1.setApellido("Doe");

        Autores autor2 = new Autores();
        autor2.setNombre("Jane");
        autor2.setApellido("Smith");

        // Crear lista de autores
        List<Autores> autores = Arrays.asList(autor1, autor2);


  //      List<String> autoresStrings = bookMapper.mapAutoresAstrings(autores);


        System.out.println("Lista de Autores "+autores);

      //  System.out.println("Lista de String "+autoresStrings);
    }
}