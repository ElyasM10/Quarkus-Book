package org.elias.fascicle.quarkus.book.TransformadorLibro;

import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.CategoriasDTO;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface CategoriaMapper {

    CategoriaMapper INSTANCE = Mappers.getMapper(CategoriaMapper.class);

    @Mapping(source = "nombre", target = "nombre")
  //  @Mapping(source ="id",target="id")
    CategoriasDTO categoriaAcategoriasDTO(Categorias categorias);


    //DTO a entidad
    @InheritInverseConfiguration
    Categorias toEntity(CategoriasDTO categoriasDTO);

    //Listas de DTOs a listas de Entidades
    List<CategoriasDTO> toCategoyDTOList(List<Categorias> categoryList);

    //Listas de Entidades a listas de DTOs
    List<Categorias> toEntityList(List<CategoriasDTO> transferibleCateroryList);

}
