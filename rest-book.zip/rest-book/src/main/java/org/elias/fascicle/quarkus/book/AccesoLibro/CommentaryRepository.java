package org.elias.fascicle.quarkus.book.AccesoLibro;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Comentarios;

import java.io.FileNotFoundException;
import java.util.List;

public interface CommentaryRepository extends PanacheRepository<Comentarios> {

    Comentarios persistCommentary(Comentarios comentarios);

    Comentarios fallbackPersistCommentary(Comentarios comentarios) throws FileNotFoundException;


    List<Comentarios> findAllCommentary();

    Comentarios  findCommentaryById(Long id);

    Comentarios  updateCommentary(Comentarios comentarios);

    void deleteCommentary(Long id);



}
