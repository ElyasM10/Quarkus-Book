package org.elias.fascicle.quarkus.book.modelo;


import jakarta.persistence.*;
import org.eclipse.microprofile.openapi.annotations.media.Schema;


@Schema(description = "Representacion de entidad Comentarios")
@Entity
public class Comentarios {

    @Column(name = "Email")
    public String email;

    @Column(name = "Texto")
    public String texto;


    @Column(name = "Puntuacion")
    public int  puntuacion;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }



    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }
}


