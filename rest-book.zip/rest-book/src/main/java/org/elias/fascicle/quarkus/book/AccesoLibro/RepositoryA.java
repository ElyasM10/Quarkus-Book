package org.elias.fascicle.quarkus.book.AccesoLibro;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.bind.JsonbBuilder;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.client.IsbnNumbers;
import org.elias.fascicle.quarkus.book.client.NumberProxy;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.jboss.logging.Logger;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;
import java.util.Random;

@ApplicationScoped
public class RepositoryA implements AuthorsRepository {


    @Inject
    Logger LOGGER;

    @Inject
    EntityManager em;





    @Override
    public Autores fallbackPersistAuthor(Autores autor) throws FileNotFoundException {
        LOGGER.warn("Falling back on persisting a author");
        String AuthorJson = JsonbBuilder.create().toJson(autor);
        try (PrintWriter out = new PrintWriter("author-"
                + Instant.now().toEpochMilli() + ".json")) {
            out.println(AuthorJson);
        }
        throw new IllegalStateException();
    }



        @Override
    public List<Autores> findAllAuthors(){
        return listAll();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Autores findAuthorById(Long id) {
        return findById(id);
    }




    @Override
    public Autores persistAuthor(Autores autores) {
        persist(autores);
        return autores;
    }



    @Override
    public Autores updateAuthor(Autores autores) {
        return em.merge(autores);
    }

    @Override
    public void deleteAuthors (Long id) {
        deleteById(id);
    }

    /*
    @Override
    public List<Book> findBooksByAuthor(Long authorId) {
        return em.createQuery("SELECT b FROM Book b JOIN b.authors a WHERE a.id = :authorId", Book.class)
                .setParameter("authorId", authorId)
                .getResultList();
    }
     */

}
