package org.elias.fascicle.quarkus.book.RecursoLibro;

import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.elias.fascicle.quarkus.book.ServicioLibro.AutoresService;
import org.elias.fascicle.quarkus.book.ServicioLibro.BookService;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.AutorMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.jboss.logging.Logger;

import java.util.List;

import static jakarta.ws.rs.core.Response.Status.NOT_FOUND;

@Path("/api/autores")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name ="Autores Endpoint")

public class AuthorResource {

    /*
        @GET
        @Path("/ping")
        @Produces(MediaType.TEXT_PLAIN)
        public static String pingBook() {
            return "ping";
        }
*/

        @Inject
        AutoresService  service;

        @Inject
        AutorMapper autorMapper;
        private static final Logger LOGGER = Logger.getLogger(org.elias.fascicle.quarkus.book.RecursoLibro.AuthorResource.class);


    @Operation(summary = "Creates a new Author")
    @APIResponse(responseCode = "201", description = "The URI of the created author",
            content = @Content(mediaType = MediaType.APPLICATION_JSON,
                    schema = @Schema(implementation = AutorDTO.class)))
        @POST
        public Response createBook(@Valid AutorDTO  autorDTO, @Context UriInfo uriInfo) {


        autorDTO = service.persistAuthor(autorDTO);


        UriBuilder builder = uriInfo.getAbsolutePathBuilder().path(Long.toString(autorDTO.getId()));
        LOGGER.debug("New book created with URI " + builder.build().toString());


        return Response.created(builder.build()).build();
        }


        ////////////////////////////////////////////////GET ALL AUTHORS//////////////////////////////////////////

        @Operation(summary = "Returns all the authors from the database") // Descripción para la documentación de OpenAPI
        @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = AutorDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
        @APIResponse(responseCode = "204", description = "No Authors") // Respuesta cuando no hay libros
        @GET
        public Response getAllAuthors() {
            List<AutorDTO> autoresDTO = service.findAllAuthors(); // Llama al servicio para obtener todos los libros
            LOGGER.debug("Total number of books " + autoresDTO); // Registra el evento en los logs
            return Response.ok(autoresDTO).build(); // Retorna la lista de libros en la respuesta
        }


    @GET
    @Operation(summary = "Returns author by a determinate  id") // Descripción para la documentación de OpenAPI
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = AutorDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
    @APIResponse(responseCode = "204", description = "No Authors by that id found") // Respuesta cuando no hay libros
    @Path("/{id}")
    public Response getAuthorbyId(@Parameter(description = "Author identifier", required = true)
                            @PathParam("id")
                            Long id){
        AutorDTO optionalAutorDTO = service.findAuthorById(id);
        if (optionalAutorDTO!= null) {
            LOGGER.debug("Found author" + optionalAutorDTO.getNombre());
            return Response.ok(optionalAutorDTO).build();
        }else{
            LOGGER.debug("No author found with id " + id);
            return Response.status(NOT_FOUND).build();
        }
    }




        ////////////////////////////////////////////////UPDATE BOOK//////////////////////////////////////////

        @Operation(summary = "Updates an existing author")
        @APIResponse(responseCode = "200", description = "The updated author", content = @Content(mediaType = MediaType.APPLICATION_JSON))
        @Counted(name = "countUpdateAuthor", description = "Counts how many times the updateAuthors method has been invoked")
        @Timed(name = "timeUpdateAuthor", description = "Times how long it takes to invoke the updateAuthor method", unit = MetricUnits.MILLISECONDS)
        @PUT
        @Path("/{id}")
        public Response updateAuthor(@PathParam("id") Long id, @Valid AutorDTO autorDTO) {
            //



            AutorDTO updatedAuthor = service.updateAuthor(autorDTO);

            LOGGER.debug("Author updated with new values: " + updatedAuthor);

            return Response.ok(updatedAuthor).build();
        }









        @Operation(summary = "Deletes an existing author") // Descripción para la documentación de OpenAPI
        @APIResponse(responseCode = "204", description = "The Author has been successfully deleted") // Respuesta esperada
        @DELETE
        @Path("/{id}")
        public Response deleteBook(@Parameter(description = "Author identifier", required = true) @PathParam("id") Long id) {
            service.deleteAuthors(id);
            LOGGER.debug("Author deleted with " + id);
            return Response.noContent().build();
        }

}






