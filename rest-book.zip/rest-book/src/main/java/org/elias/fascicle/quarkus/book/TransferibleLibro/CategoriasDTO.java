package org.elias.fascicle.quarkus.book.TransferibleLibro;

import jakarta.persistence.*;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;

import java.util.List;

public class CategoriasDTO {


        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String nombre;


        @OneToMany(mappedBy = "categoriaPadre")
        private List<org.elias.fascicle.quarkus.book.modelo.Categorias> subcategorias;

        @ManyToOne
        @JoinColumn(name = "categoria_padre_id")
        private org.elias.fascicle.quarkus.book.modelo.Categorias categoriaPadre;

        @OneToMany(mappedBy = "categoria")
        private List<Book> libros;





        //getters y setter


        public org.elias.fascicle.quarkus.book.modelo.Categorias getCategoriaPadre() {
            return categoriaPadre;
        }

        public void setCategoriaPadre(org.elias.fascicle.quarkus.book.modelo.Categorias categoriaPadre) {
            this.categoriaPadre = categoriaPadre;
        }


        public void setSubcategorias(List<org.elias.fascicle.quarkus.book.modelo.Categorias> subcategorias) {
            this.subcategorias = subcategorias;
        }

        public List<org.elias.fascicle.quarkus.book.modelo.Categorias> getSubcategorias() {
            return subcategorias;
        }


        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }
}
