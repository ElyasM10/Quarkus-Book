package org.elias.fascicle.quarkus.book.ServicioLibro;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.elias.fascicle.quarkus.book.AccesoLibro.AuthorsRepository;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.AutorMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;

import java.io.FileNotFoundException;
import java.util.List;

import static jakarta.ws.rs.core.Response.Status.NOT_FOUND;

@ApplicationScoped
public class AutoresService {

    @Inject
    AuthorsRepository repository;




    //Persists a given book
    public AutorDTO persistAuthor(AutorDTO autorDTO) {
        return AutorMapper.INSTANCE. autorToAutorDTO(repository.persistAuthor(AutorMapper.INSTANCE.toEntity(autorDTO)));
    }



    @Fallback(fallbackMethod = "fallbackPersistAuthor")
    // Método de fallback

    public AutorDTO fallbackPersistAuthor(AutorDTO autorDTO) throws FileNotFoundException {
        return AutorMapper.INSTANCE.autorToAutorDTO(repository.fallbackPersistAuthor(AutorMapper.INSTANCE.toEntity(autorDTO)));
    }





    @Transactional(Transactional.TxType.SUPPORTS)
    public List<AutorDTO> findAllAuthors() {
        // Obtener todos los libros desde el repositorio
        return AutorMapper.INSTANCE.toAutorDTOList(repository. findAllAuthors());
    }








    @Transactional(Transactional.TxType.SUPPORTS)
    //Finds the book by his id
    public AutorDTO findAuthorById(Long id) {
        return AutorMapper.INSTANCE.autorToAutorDTO(repository.findAuthorById(id));
    }


    @Transactional(Transactional.TxType.REQUIRED)
    public AutorDTO updateAuthor(AutorDTO autorDTO) {

        return AutorMapper.INSTANCE.autorToAutorDTO(repository.updateAuthor(AutorMapper.INSTANCE.toEntity(autorDTO)));
    }




    public void deleteAuthors(Long id) {
        repository.deleteAuthors(id);
    }


}
