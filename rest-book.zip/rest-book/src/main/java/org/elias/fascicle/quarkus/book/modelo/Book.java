package org.elias.fascicle.quarkus.book.modelo;


import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.*;
import jakarta.validation.Valid;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.naming.StringRefAddr;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.wildfly.common.annotation.NotNull;
import java.math.BigDecimal;
import java.net.URL;

@Schema(description = "Representacion de entidad Book")
@Entity
// Indica que esta clase es una entidad que se mapeará a una tabla en la base de datos.

//public class Book extends PanacheEntity {
public class Book {

    // La clase Book extiende PanacheEntity, lo que proporciona métodos de utilidad para operaciones  con CRUD.

    @NotNull //indica que no puede ser nulo
    @Schema(required = true)
    public String title;
    @Column(name = "isbn_13")
    // Mapea este campo a la columna 'isbn_13' en la tabla de la base de datos
    public String isbn13;
    @Column(name = "isbn_10")
    // Mapea este campo a la columna 'isbn_10' en la tabla de la base de datos
    public String isbn10;
   // public String author;
    @Column(name = "year_of_publication")
    // Mapea este campo a la columna 'year of publication' en la tabla de la base de datos
    public int yearOfPublication;
    @Column(name = "nb_of_pages")
    // Mapea este campo a la columna 'nb_of_pages' en la tabla de la base de datos
    public int nbOfPages;
    @Min(1)
    @Max(10) // Anotaciones que validan que el valor de rank esté entre 1 y 10.
    public int rank;
    public BigDecimal price;
    @Column(name = "small_image_url")
    // Mapea este campo a la columna 'small_image_url' en la tabla de la base de datos
    public URL smallImageUrl;
    @Column(name = "medium_image_url")
    // Mapea este campo a la columna 'medium_image_url' en la tabla de la base de datos
    public URL mediumImageUrl;
    @Column(length = 10000)
    // Define la longitud máxima de este campo en la base de datos.
    @Size(min = 1, max = 10000)
    // Anotación que valida que el tamaño del campo esté entre 1 y 10000 caracteres.
    public String description;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id; // Campo ID que actúa como identificador único



    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "Autores_Libros",
            joinColumns = @JoinColumn(name = "libro_id"),
            inverseJoinColumns = @JoinColumn(name = "autor_id")
    )
 //   @Column(name="Autores")
    public List<Autores> autores;

 //   public  long autorBook = Autores.getId();

    //@ManyToOne
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_categoria")
    public Categorias categoria;




    public void setCategoria(Categorias categoria) {
        this.categoria = categoria;
    }

    public Categorias getCategoria() {
        return categoria;
    }

    public void setAutores(List<Autores> autores){
         this.autores = autores;
    }

    //getters y setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIsbn13() {
        return isbn13;
    }

    public void setIsbn13(String isbn13) {
        this.isbn13 = isbn13;
    }

    public String getIsbn10() {
        return isbn10;
    }

    public void setIsbn10(String isbn10) {
        this.isbn10 = isbn10;
    }

    /*
    public void setAuthor(String author) {
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }
*/
    public int getYearOfPublication() {
        return yearOfPublication;
    }

    public void setYearOfPublication(int yearOfPublication) {
        this.yearOfPublication = yearOfPublication;
    }

    public void setNbOfPages(int nbOfPages) {
        this.nbOfPages = nbOfPages;
    }

    public int getNbOfPages() {
        return nbOfPages;
    }

    @Min(1)
    @Max(10)
    public int getRank() {
        return rank;
    }


    public void setRank(@Min(1) @Max(10) int rank) {
        this.rank = rank;
    }


    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public URL getMediumImageUrl() {
        return mediumImageUrl;
    }

    public void setMediumImageUrl(URL mediumImageUrl) {
        this.mediumImageUrl = mediumImageUrl;
    }

    public void setSmallImageUrl(URL smallImageUrl) {
        this.smallImageUrl = smallImageUrl;
    }

    public URL getSmallImageUrl() {
        return smallImageUrl;
    }

    public @Size(min = 1, max = 10000) String getDescription() {
        return description;
    }

    public void setDescription(@Size(min = 1, max = 10000) String description) {
        this.description = description;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public List<Autores> getAutores() {
        return autores;
    }
}
    /*
    public static Book findRandom() { // Método estático para encontrar un libro aleatorio en la base de datos.
        long countBooks = Book.count();  // Obtiene el número total de libros en la base de datos.



        int randomBook = new Random().nextInt((int) countBooks);   // Genera un índice aleatorio basado en el número total de libros.
        return Book.findAll().page(randomBook, 1).firstResult();  // Retorna un libro aleatorio usando el índice generado.
    }

    public Book persistBook(@Valid Book book) {  // Método para persistir (guardar) un libro en la base de datos.
        Book.persist(book);  // Persiste el libro pasado como argumento en la base de datos.
        return book; //retorna el libro persistido
    }
*/




