package org.elias.fascicle.quarkus.book.AccesoLibro;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;

import java.io.FileNotFoundException;
import java.util.List;

public interface CategoriaRepository extends PanacheRepository<Categorias> {


    Categorias fallbackPersistCategory(Categorias categorias) throws FileNotFoundException;

    List<Categorias> findAllCategory();

    Categorias findCategoryById(Long id);

    Categorias persistCategory(Categorias categorias);

    Categorias updateCategory(Categorias categorias);

    void deleteCategory(Long id);



}
