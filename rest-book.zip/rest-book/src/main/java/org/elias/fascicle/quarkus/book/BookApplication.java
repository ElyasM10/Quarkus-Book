package org.elias.fascicle.quarkus.book;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
import org.eclipse.microprofile.openapi.annotations.ExternalDocumentation;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Contact;
import org.eclipse.microprofile.openapi.annotations.info.Info;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

@ApplicationPath("/")
@OpenAPIDefinition(
        info = @Info(title = "org.agoncal.fascicle.quarkus.book.Book API",
                description = "This API allows CRUD operations on books",
                version = "1.0",
                contact = @Contact(name = "@agoncal", url = "https://twitter.com/agoncal")),
        externalDocs = @ExternalDocumentation(url = "https://github.com/agoncal/agoncal- ascicle-quarkus-pract", description = "All the Practising Quarkus code"),
        tags = {
                @Tag(name = "api", description = "Public API that can be used by anybody"),
                @Tag(name = "books", description = "Anybody interested in books")
        }
)


//@QuarkusTestResource: Usado para definir un recurso de prueba  (e.j. una baseDeDatos, una herramienta , etc.)
//@TestMethodOrder: JUnit annotation used to configure the MethodOrderer for the test methods (e.g.@Order(1), @Order(2), etc.)
public class BookApplication extends Application {
}
