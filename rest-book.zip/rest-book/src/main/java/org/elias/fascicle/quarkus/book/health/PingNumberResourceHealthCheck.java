package org.elias.fascicle.quarkus.book.health;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.eclipse.microprofile.health.HealthCheckResponse;
import org.eclipse.microprofile.health.Liveness;
import org.elias.fascicle.quarkus.book.RecursoLibro.BookResource;


@Liveness // Indica que este chequeo es para verificar si el servicio está vivo
@ApplicationScoped // Define que esta clase tiene un ciclo de vida de aplicación en CDI
public class PingNumberResourceHealthCheck implements org.eclipse.microprofile.health.HealthCheck {

    @Inject
    BookResource bookResource; // Inyección del recurso que gestiona los endpoints de libros

    @Override
    public HealthCheckResponse call() {
        bookResource.pingBook(); // Llama al método pingBook para verificar si el recurso está disponible
        return HealthCheckResponse.named("Ping Number REST Endpoint").up().build(); // Construye y retorna la respuesta de salud
    }
}