package org.elias.fascicle.quarkus.book.ServicioLibro;


import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.elias.fascicle.quarkus.book.AccesoLibro.Repository;

import org.elias.fascicle.quarkus.book.AccesoLibro.RepositoryA;
import org.elias.fascicle.quarkus.book.AccesoLibro.RepositoryCategory;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.AutorMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.jboss.logging.Logger;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/*
@ApplicationScoped
@Transactional(Transactional.TxType.REQUIRED)
public class BookService extends Repository {

    private static final Logger LOGGER = Logger.getLogger(BookService.class);
    // @RestClient // @RestClient CDI se utiliza para indicar que este punto de inyección está destinado a usar una instancia de un cliente REST con tipo seguro.

    // Inyecta una instancia del cliente REST NumberProxy para interactuar con el microservicio de números ISBN.
    @Inject
    EntityManager em;
    @Inject
    @RestClient
    NumberProxy numberProxy;

    @Fallback(fallbackMethod = "fallbackPersistBook")
    // Define un método de fallback para manejar fallos en la ejecución de persistBook.
    public Book persistBook(@Valid Book book) {
        // El método persistBook recibe un objeto Book válido y realiza las siguientes operaciones:

        // Llama al microservicio para generar números ISBN. `numberProxy` es el cliente REST configurado para esto.
        IsbnNumbers isbnNumbers = numberProxy.generateIsbnNumbers();

        // Asigna los números ISBN generados al objeto Book.
        book.isbn13 = isbnNumbers.getIsbn13();
        book.isbn10 = isbnNumbers.getIsbn10();

        // Persiste el objeto Book en la base de datos. Este método se asume que guarda el libro en algún almacenamiento persistente.
        Book.persist(book);

        // Devuelve el objeto Book que ha sido persistido.
        return book;
    }

    // Método de fallback que se invoca si ocurre una excepción en persistBook.
    private Book fallbackPersistBook(Book book) throws FileNotFoundException {
        // muestra una advertencia indicando que se está utilizando el método de fallback.
        LOGGER.warn("Falling back on persisting a book");

        // Serializa el objeto Book a una cadena JSON utilizando Jsonbuikdr.
        String bookJson = JsonbBuilder.create().toJson(book);

        // Intenta guardar el JSON en un archivo con un nombre basado en el tiempo actual para evitar sobrescrituras.
        try (PrintWriter out = new PrintWriter("book-" + Instant.now().toEpochMilli() + ".json")) {
            out.println(bookJson);
        }

        // Lanza una excepción para indicar que ocurrió un problema al persistir el libro.
        throw new IllegalStateException();
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Book> findAllBooks() {
        return Book.listAll();
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public Optional<Book> findBookById(Long id) {
        return Book.findByIdOptional(id);
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public Book findRandomBook() {
        Book randomBook = null;
        while (randomBook == null) { //mientras el libro sea null
            randomBook = Book.findRandom(); //va encontrar un libro random
        }
        return randomBook; //devuelve el libro aleatorio
    }

    public Book updateBook(@Valid Book book) {
        Book entity = em.merge(book);
        return entity;
    }

    public void deleteBook(Long id) {
        Book.deleteById(id);
    }

}
*/




@ApplicationScoped
@Transactional(Transactional.TxType.REQUIRED)
public class BookService {

    private static final Logger LOGGER = Logger.getLogger(BookService.class);

    @Inject
    Repository repository;

    @Inject
    RepositoryA autorRepository;

    @Inject
    RepositoryCategory categoriaRepository;

    @Inject
    BookMapper bookMapper;




    //Persists a given book

     //servicio
   public BookDTO persistBook(BookDTO bookDTO) {
        return bookMapper.INSTANCE. LibroAlibroDTO(repository.persistBook(bookMapper.INSTANCE.toEntity(bookDTO)));
    }


/*
    // Servicio
    public BookDTO persistBook(BookDTO bookDTO) {

        // ----------------------------------| V0.1 |----------------------------------
        List<Long> author_ids = getAuthorIDs(bookDTO);

        return BookMapper.INSTANCE.LibroAlibroDTO(repository.persistBook(BookMapper.INSTANCE.toEntity(bookDTO), author_ids));
    }


    public List<Long> getAuthorIDs(BookDTO bookDTO){
        List<Long> author_ids = new ArrayList<>();
        for (AutorDTO autor :bookDTO.getAutores()){
            if (autor.getId() != null){
                author_ids.add(autor.getId());
            }
            else{
               AutorDTO autorPersistido = AutorMapper.INSTANCE.autorToAutorDTO(autorRepository.persistAuthor( AutorMapper.INSTANCE.toEntity(autor)));
                author_ids.add(autorPersistido.getId());
            }
        }
        return author_ids;
    }
*/



    @Fallback(fallbackMethod = "fallbackPersistBook")
    // Método de fallback

    public BookDTO fallbackPersistBook(BookDTO bookDTO) throws FileNotFoundException {
        return BookMapper.INSTANCE.LibroAlibroDTO(repository.fallbackPersistBook(bookMapper.INSTANCE.toEntity(bookDTO)));
    }




    @Transactional(Transactional.TxType.SUPPORTS)
    public List<BookDTO> findAllBooks() {
        // Obtener todos los libros desde el repositorio
        return BookMapper.INSTANCE.toLibroDTOList(repository.findAllBooks());
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public List<BookDTO> findBooksByAuthor(Long authorId) {
        return BookMapper.INSTANCE.toLibroDTOList(repository.findBooksByAuthor(authorId));
    }

    @Transactional(Transactional.TxType.SUPPORTS)
    public List<BookDTO> findAllBooksWithAuthor(){
        return BookMapper.INSTANCE.toLibroDTOList(repository.findAllBooksAuthors());
    }

  //  @Transactional(Transactional.TxType.SUPPORTS)
   /// public List<AutorDTO> findAllAuthors(){
      //  return AutorMapper.INSTANCE.toAutorDTOList(repository.findAllAuthors());
   // }

    @Transactional(Transactional.TxType.SUPPORTS)
    public List<BookDTO>  AverageScore(int rank) {

        return BookMapper.INSTANCE.toLibroDTOList(repository.averageScore(rank));
    }

   @Transactional(Transactional.TxType.SUPPORTS)
   public List<BookDTO> getBooksByCategoryIncludingSubcategories(Long categoryId){
      return BookMapper.INSTANCE.toLibroDTOList(repository.getBooksByCategoryIncludingSubcategories(categoryId));
   }



    @Transactional(Transactional.TxType.SUPPORTS)
    //Finds the book by his id
    public BookDTO findBookById(Long id) {
        return BookMapper.INSTANCE.LibroAlibroDTO(repository.findBookById(id));
    }




    @Transactional(Transactional.TxType.SUPPORTS)
    public BookDTO findRandomBook() {

        return BookMapper.INSTANCE.LibroAlibroDTO(repository.findRandomBook());
    }






    @Transactional(Transactional.TxType.REQUIRED)
    public BookDTO updateBook(BookDTO bookDTO) {
        // Convertir BookDTO a Book
        return BookMapper.INSTANCE.LibroAlibroDTO(repository.updateBook(BookMapper.INSTANCE.toEntity(bookDTO)));
    }




    public void deleteBook(Long id) {
        repository.deleteBook(id);
   }
}
