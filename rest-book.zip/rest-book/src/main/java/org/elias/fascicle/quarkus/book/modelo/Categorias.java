package org.elias.fascicle.quarkus.book.modelo;

import jakarta.persistence.Entity;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import jakarta.persistence.*;

import java.util.List;

@Schema(description = "Representacion de entidad Categorias")
@Entity
public class Categorias {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Nombre")
    private String nombre;


    @ManyToOne
    @JoinColumn(name = "id_padre")
    private Categorias categoriaPadre;

    @OneToMany(mappedBy = "categoriaPadre")
    public List<Categorias> subCategorias;


    @OneToMany(mappedBy = "categoria")
    private List<Book> books;


   // @Column(name = "subcategoria_nombre")
    public String subCategoriaNombre;




    @Override
    public String toString() {
        return getSubCategoriaNombre();
    }


    public String getSubCategoriaNombre() {
        return subCategoriaNombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
