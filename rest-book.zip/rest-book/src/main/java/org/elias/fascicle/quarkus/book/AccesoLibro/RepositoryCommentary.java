package org.elias.fascicle.quarkus.book.AccesoLibro;
import jakarta.inject.Inject;
import jakarta.json.bind.JsonbBuilder;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.elias.fascicle.quarkus.book.AccesoLibro.CommentaryRepository;

import jakarta.enterprise.context.ApplicationScoped;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Comentarios;
import org.jboss.logging.Logger;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;

@ApplicationScoped
public class RepositoryCommentary implements  CommentaryRepository{

    @Inject
    Logger LOGGER;

    @Inject
    EntityManager em;


    @Override
    public Comentarios fallbackPersistCommentary(Comentarios comentarios) throws FileNotFoundException {
        LOGGER.warn("Falling back on persisting a author");
        String CommentaryJson = JsonbBuilder.create().toJson(comentarios);
        try (PrintWriter out = new PrintWriter("commentary-"
                + Instant.now().toEpochMilli() + ".json")) {
            out.println(CommentaryJson);
        }
        throw new IllegalStateException();
    }



    @Override
    public List<Comentarios> findAllCommentary(){
        return listAll();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Comentarios findCommentaryById(Long id) {
        return findById(id);
    }


    @Override
    public Comentarios persistCommentary(Comentarios comentarios) {
        persist(comentarios);
        return comentarios;
    }



    @Override
    public Comentarios updateCommentary(Comentarios comentarios) {
        return em.merge(comentarios);
    }

    @Override
    public void deleteCommentary (Long id) {
        deleteById(id);
    }
}
