package org.elias.fascicle.quarkus.book.AccesoLibro;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;

import java.io.FileNotFoundException;
import java.util.List;

public interface AuthorsRepository extends PanacheRepository<Autores> {





    Autores persistAuthor(Autores autores);

    Autores fallbackPersistAuthor(Autores autores) throws FileNotFoundException;


    List<Autores> findAllAuthors();

    Autores findAuthorById(Long id);

    Autores updateAuthor(Autores autor);

    void deleteAuthors(Long id);



  //  List<Book> findBooksByAuthor(Long authorId);

}