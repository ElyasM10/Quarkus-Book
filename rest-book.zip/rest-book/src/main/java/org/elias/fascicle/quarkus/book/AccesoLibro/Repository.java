package org.elias.fascicle.quarkus.book.AccesoLibro;


import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.bind.JsonbBuilder;
import jakarta.persistence.EntityManager;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.transaction.Transactional;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.client.IsbnNumbers;
import org.elias.fascicle.quarkus.book.client.NumberProxy;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.jboss.logging.Logger;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Random;


@ApplicationScoped
public class Repository implements BookRepository {


    @Inject
    Logger LOGGER;

    @Inject
    EntityManager em;

    @Inject
    @RestClient
    NumberProxy numberProxy;


    @Override
    public Book fallbackPersistBook(Book book) throws FileNotFoundException {
        LOGGER.warn("Falling back on persisting a book");
        String bookJson = JsonbBuilder.create().toJson(book);
        try (PrintWriter out = new PrintWriter("book-"
                + Instant.now().toEpochMilli() + ".json")) {
            out.println(bookJson);
        }
        throw new IllegalStateException();
    }

    @Override
    public Book findRandomBook() {
        long countBooks = count();
        if (countBooks == 0) {
            return null;
        }
        int randomBook = new Random().nextInt((int) countBooks);
        return findAll().page(randomBook, 1).firstResult();
    }

    @Override
    public List<Book> findAllBooks() {
        return listAll();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Book findBookById(Long id) {
        return findById(id);
    }

    @Override
    public Book persistBook(Book book) {

        IsbnNumbers isbnNumbers = numberProxy.generateIsbnNumbers();

        book.setIsbn13(isbnNumbers.getIsbn13());
        book.setIsbn10(isbnNumbers.getIsbn10());
        persist(book);
        return book;
    }


    @Override
    public Book updateBook(Book book) {
        return em.merge(book);
    }

    @Override
    public void deleteBook(Long id) {
        deleteById(id);
    }


    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Book> findBooksByAuthor(Long authorId) {
        // La consulta utiliza un JOIN para combinar las entidades Book y Author.
        // El JOIN se realiza sobre la relación que une a los libros con los autores.
        // `b` es el alias para la entidad Book.
        // `a` es el alias para la entidad Author.

        return em.createQuery("SELECT b FROM Book b JOIN b.autores a WHERE a.id = :authorId", Book.class) //Tipo de resultado esperado: Listado de objetos Book
                .setParameter("authorId", authorId)
                .getResultList();
        //Autores es nombre de la lista que defino en book
        // Establece el parámetro `authorId` en la consulta.
        // Este parametro sera utilizado para filtrar los libros que tienen el autor con el id proporcionado.
        // Ejecuta la consulta y obtiene el resultado como una lista de objetos Book.
        // La lista contiene todos los libros que están asociados con el autor especificado.
    }



    /*
    @Override
    public List<Book> findAllBooksAuthors() {
        // Modificar la consulta para obtener todos los libros y sus autores
        return em.createQuery(
                "SELECT DISTINCT b FROM Book b LEFT JOIN b.autores a", //con distinct me aseguro de que no haya duplicadas
                Book.class
        ).getResultList();
    }
*/

    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Book> findAllBooksAuthors() {
        return em.createQuery("SELECT DISTINCT b FROM Book b LEFT JOIN FETCH b.categoria LEFT JOIN FETCH b.autores", Book.class)
                .getResultList();
    }


    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Book> averageScore(int rank) {
        return em.createQuery("SELECT b FROM Book b WHERE b.rank > :rank", Book.class)
                .setParameter("rank", rank)
                .getResultList();
    }





/*
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Book> getBooksByCategoryIncludingSubcategories(Long categoryId) {
        // Primero, obtén la categoría principal
        Categorias categoria = em.find(Categorias.class, categoryId);

        if (categoria == null) {
            throw new IllegalArgumentException("Category with ID " + categoryId + " not found.");
        }

        // Encuentra todas las subcategorías
        List<Categorias> subcategories = em.createQuery(
                        "SELECT c FROM Categorias c WHERE c.categoriaPadre.id = :categoryId", Categorias.class)
                .setParameter("categoryId", categoryId)
                .getResultList();

        // Incluye la categoría principal en la lista de subcategorías
        subcategories.add(categoria);

        // Obtén todos los libros de la categoría principal y sus subcategorías
        return em.createQuery(
                        "SELECT DISTINCT b FROM Book b " +
                                "JOIN FETCH b.categoria c " +
                                "LEFT JOIN FETCH b.autores a " +
                                "WHERE c IN :categories", Book.class)
                .setParameter("categories", subcategories)
                .getResultList();
    }
 */

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Book> getBooksByCategoryIncludingSubcategories(Long categoryId) {
        // FROM retorna todas las clases de la tabla.
        // SELECT escoge que objetos y propiedades va a devolver.
        // WHERE permite refinar la lista de instancias retornadas.
        // IN, OR (operador lógico) son operaciones utilizados en la clausula WHERE

        return find("SELECT b FROM Book b WHERE b.categoria.id IN " +
                "(SELECT c.id FROM Categorias c WHERE c.id= ?1 OR c.categoriaPadre.id = ?1)", categoryId).list();


    }

}
