package org.elias.fascicle.quarkus.book.client;



import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
@Path("/api/numbers/book")
@Produces(MediaType.APPLICATION_JSON)
@RegisterRestClient
//@RegisterRestClientA marker annotation to register a rest client at runtime
public interface NumberProxy {
    @GET
    IsbnNumbers generateIsbnNumbers();
}