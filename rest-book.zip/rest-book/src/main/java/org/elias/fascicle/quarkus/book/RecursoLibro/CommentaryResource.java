package org.elias.fascicle.quarkus.book.RecursoLibro;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.elias.fascicle.quarkus.book.ServicioLibro.CommentaryService;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.ComentariosDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.AutorMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.CommentaryMapper;
import org.jboss.logging.Logger;

import java.util.List;

import static jakarta.ws.rs.core.Response.Status.NOT_FOUND;


@Path("/api/comentarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name ="Comentarios Endpoint")

@ApplicationScoped
public class CommentaryResource {


    @Inject
    CommentaryService  service;

    @Inject
    CommentaryMapper commentaryMapper;
    private static final Logger LOGGER = Logger.getLogger(org.elias.fascicle.quarkus.book.RecursoLibro.CommentaryResource.class);


    @Operation(summary = "Creates a new Commentary")
    @APIResponse(responseCode = "201", description = "The URI of the created author",
            content = @Content(mediaType = MediaType.APPLICATION_JSON,
                    schema = @Schema(implementation = AutorDTO.class)))
    @POST
    public Response createCommentary(@Valid ComentariosDTO comentariosDTO, @Context UriInfo uriInfo) {


        comentariosDTO = service.persistCommentary(comentariosDTO);


        UriBuilder builder = uriInfo.getAbsolutePathBuilder().path(Long.toString(comentariosDTO.getId()));
        LOGGER.debug("New book created with URI " + builder.build().toString());


        return Response.created(builder.build()).build();
    }


    ////////////////////////////////////////////////GET ALL Commentary//////////////////////////////////////////

    @Operation(summary = "Returns all the commentarys from the database") // Descripción para la documentación de OpenAPI
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = AutorDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
    @APIResponse(responseCode = "204", description = "No Commentary") // Respuesta cuando no hay libros
    @GET
    public Response getAllCommentarys() {
        List<ComentariosDTO> comentariosDTO = service.findAllCommentary(); // Llama al servicio para obtener todos los libros
        LOGGER.debug("Total number of commentary " + comentariosDTO); // Registra el evento en los logs
        return Response.ok(comentariosDTO).build(); // Retorna la lista de libros en la respuesta
    }


    @GET
    @Operation(summary = "Returns a commentary by a determinate  id") // Descripción para la documentación de OpenAPI
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ComentariosDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
    @APIResponse(responseCode = "204", description = "No Commentary by that id found") // Respuesta cuando no hay libros
    @Path("/{id}")
    public Response getAuthorbyId(@Parameter(description = "Commentary identifier", required = true)
                                  @PathParam("id")
                                  Long id){
        ComentariosDTO optionalCommentaryDTO = service.findCommentaryById(id);
        if (optionalCommentaryDTO!= null) {
            LOGGER.debug("Found commentary" + optionalCommentaryDTO.getTexto());
            return Response.ok(optionalCommentaryDTO).build();
        }else{
            LOGGER.debug("No author found with id " + id);
            return Response.status(NOT_FOUND).build();
        }
    }




    ////////////////////////////////////////////////UPDATE Commentary//////////////////////////////////////////

    @Operation(summary = "Updates an existing commentary")
    @APIResponse(responseCode = "200", description = "The updated commentary", content = @Content(mediaType = MediaType.APPLICATION_JSON))
    @Counted(name = "countUpdateCommentary", description = "Counts how many times the updateCommentary method has been invoked")
    @Timed(name = "timeUpdateCommentary", description = "Times how long it takes to invoke the updateCommentary method", unit = MetricUnits.MILLISECONDS)
    @PUT
    @Path("/{id}")
    public Response updateCommentary(@PathParam("id") Long id, @Valid ComentariosDTO comentariosDTO) {
        //



        ComentariosDTO updatedCommentary = service.updateCommentary(comentariosDTO);

        LOGGER.debug("Commentary updated with new values: " + updatedCommentary);

        return Response.ok(updatedCommentary).build();
    }









    @Operation(summary = "Deletes an existing Commentary") // Descripción para la documentación de OpenAPI
    @APIResponse(responseCode = "204", description = "The Commentary has been successfully deleted") // Respuesta esperada
    @DELETE
    @Path("/{id}")
    public Response deleteCommentary(@Parameter(description = "Commentary identifier", required = true) @PathParam("id") Long id) {
        service.deleteCommentary(id);
        LOGGER.debug("Commentary deleted with " + id);
        return Response.noContent().build();
    }



}
