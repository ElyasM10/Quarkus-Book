package org.elias.fascicle.quarkus.book.AccesoLibro;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.bind.JsonbBuilder;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.jboss.logging.Logger;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;


@ApplicationScoped
public class RepositoryCategory implements  CategoriaRepository{

    @Inject
    Logger LOGGER;

    @Inject
    EntityManager em;


    @Override
    public Categorias fallbackPersistCategory(Categorias category) throws FileNotFoundException {
        LOGGER.warn("Falling back on persisting a category");
        String categoryJson = JsonbBuilder.create().toJson(category);
        try (PrintWriter out = new PrintWriter("category-"
                + Instant.now().toEpochMilli() + ".json")) {
            out.println(categoryJson);
        }
        throw new IllegalStateException();
    }



    @Override
    public List<Categorias> findAllCategory(){
        return listAll();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Categorias findCategoryById(Long id) {
        return findById(id);
    }


    @Override
    public Categorias persistCategory(Categorias categorias) {
        persist(categorias);
        return categorias;
    }



    @Override
    public Categorias updateCategory(Categorias categorias) {
        return em.merge(categorias);
    }

    @Override
    public void deleteCategory(Long id) {
        deleteById(id);
    }


}
