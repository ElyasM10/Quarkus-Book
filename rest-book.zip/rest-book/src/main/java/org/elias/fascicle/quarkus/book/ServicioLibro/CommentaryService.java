package org.elias.fascicle.quarkus.book.ServicioLibro;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.elias.fascicle.quarkus.book.AccesoLibro.AuthorsRepository;
import org.elias.fascicle.quarkus.book.AccesoLibro.CommentaryRepository;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.ComentariosDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.AutorMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.CommentaryMapper;


import java.io.FileNotFoundException;
import java.util.List;

@ApplicationScoped
public class CommentaryService {

    @Inject
    CommentaryRepository repository;




    //Persists a given book
    public ComentariosDTO persistCommentary(ComentariosDTO comentariosDTO) {
        return CommentaryMapper.INSTANCE. comentariosAcomentariosDTO(repository.persistCommentary(CommentaryMapper.INSTANCE.toEntity(comentariosDTO)));
    }



    @Fallback(fallbackMethod = "fallbackPersistCommentary")
    // Método de fallback

    public ComentariosDTO  fallbackPersistCommentary(ComentariosDTO  comentariosDTO ) throws FileNotFoundException {
        return CommentaryMapper.INSTANCE.comentariosAcomentariosDTO(repository.fallbackPersistCommentary(CommentaryMapper.INSTANCE.toEntity(comentariosDTO)));
    }





    @Transactional(Transactional.TxType.SUPPORTS)
    public List<ComentariosDTO> findAllCommentary() {
        // Obtener todos los libros desde el repositorio
        return CommentaryMapper.INSTANCE. toCommentaryDTOList(repository. findAllCommentary());
    }








    @Transactional(Transactional.TxType.SUPPORTS)
    //Finds the book by his id
    public ComentariosDTO findCommentaryById(Long id) {
        return CommentaryMapper.INSTANCE.comentariosAcomentariosDTO(repository.findCommentaryById(id));
    }


    @Transactional(Transactional.TxType.REQUIRED)
    public ComentariosDTO updateCommentary(ComentariosDTO comentariosDTO) {

        return CommentaryMapper.INSTANCE.comentariosAcomentariosDTO(repository.updateCommentary(CommentaryMapper.INSTANCE.toEntity(comentariosDTO)));
    }




    public void deleteCommentary(Long id) {
        repository.deleteCommentary(id);
    }



}
