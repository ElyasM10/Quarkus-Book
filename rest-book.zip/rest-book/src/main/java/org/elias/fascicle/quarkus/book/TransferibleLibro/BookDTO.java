package org.elias.fascicle.quarkus.book.TransferibleLibro;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.net.URL;
import java.util.List;

public class BookDTO {

        public String title;


        public String isbn13;


        public String isbn10;
       // public String author;


        public int yearOfPublication;


        public int nbOfPages;

        public int rank;
        public BigDecimal price;

        public URL smallImageUrl;


        public URL mediumImageUrl;
      //  @Column(length = 10000)

      //  @Size(min = 1, max = 10000)

        public String description;

        public Long id;

        public Long id_categoria;

      //  public Long id_autor;

        public String categoriaNombre;

      public List<String> autoresString;

    //   public List<String> subcategoriasString;

    // public Categorias Categoria;

    //    public String subcategoriaNombre;



   public List<AutorDTO> autores;



    public void  setAutores(List<AutorDTO> autores){
        this.autores = autores;

    }

    public List<AutorDTO> getAutores() {
        return autores;
    }



    public List<String> getAutoresString() { return autoresString; }

/*
     public Long getId_autor(){
        return  id_autor;
     }
*/


    public void setidCategoria(Long id_categoria) {
        this.id_categoria = id_categoria;
    }

    public Long getidCategoria() {
        return id_categoria;
    }


    public void setAutoresString(List<String> autoresString) { this.autoresString = autoresString; }

    public String getCategoriaNombre() {
        return categoriaNombre;
    }

    public void setCategoriaNombre(String categoriaNombre) {
        this.categoriaNombre = categoriaNombre;
    }

    public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getIsbn13() {
            return isbn13;
        }

        public void setIsbn13(String isbn13) {
            this.isbn13 = isbn13;
        }

        public String getIsbn10() {
            return isbn10;
        }

        public void setIsbn10(String isbn10) {
            this.isbn10 = isbn10;
        }

        /*
        public void setAuthor(String author) {
            this.author = author;
        }

        public String getAuthor() {
            return author;
        }
*/
        public int getYearOfPublication() {
            return yearOfPublication;
        }

        public void setYearOfPublication(int yearOfPublication) {
            this.yearOfPublication = yearOfPublication;
        }

        public void setNbOfPages(int nbOfPages) {
            this.nbOfPages = nbOfPages;
        }

        public int getNbOfPages() {
            return nbOfPages;
        }

      //  @Min(1)
       // @Max(10)
        public int getRank()
        {
            return rank;
        }


    //    public void setRank(@Min(1) @Max(10) int rank)
       public void setRank(int rank)
        {
            this.rank = rank;
        }


        public void setPrice(BigDecimal price) {
            this.price = price;
        }

        public BigDecimal getPrice() {
            return price;
        }

        public URL getMediumImageUrl() {
            return mediumImageUrl;
        }

        public void setMediumImageUrl(URL mediumImageUrl) {
            this.mediumImageUrl = mediumImageUrl;
        }

        public void setSmallImageUrl(URL smallImageUrl) {
            this.smallImageUrl = smallImageUrl;
        }

        public URL getSmallImageUrl() {
            return smallImageUrl;
        }

       // public @Size(min = 1, max = 10000) String getDescription()
       public String getDescription()
        {
            return description;
        }

        //public void setDescription(@Size(min = 1, max = 10000) String description) {
            public void setDescription(String description) {
            this.description = description;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public Long getId() {
            return id;
        }
    }





