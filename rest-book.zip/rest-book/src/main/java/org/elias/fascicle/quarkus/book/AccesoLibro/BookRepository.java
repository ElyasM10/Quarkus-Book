package org.elias.fascicle.quarkus.book.AccesoLibro;



import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.json.bind.JsonbBuilder;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.elias.fascicle.quarkus.book.ServicioLibro.BookService;
import org.elias.fascicle.quarkus.book.client.IsbnNumbers;
import org.elias.fascicle.quarkus.book.client.NumberProxy;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.jboss.logging.Logger;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Random;


@ApplicationScoped
//public class  BookRepository implements  PanacheRepository <Book>{
    public interface BookRepository extends   PanacheRepository <Book>{

    Book fallbackPersistBook(Book book) throws FileNotFoundException;

    Book findRandomBook();

     List<Book> findAllBooks();

     Book findBookById(Long id);

     Book persistBook(Book book);

     Book updateBook(Book book);

    void deleteBook(Long id);

    List<Book> findBooksByAuthor(Long authorId);

    List<Book> findAllBooksAuthors();

 //   List<Autores> findAllAuthors();

    List<Book> averageScore(int rank);

    List<Book> getBooksByCategoryIncludingSubcategories(Long categoryId);

}

