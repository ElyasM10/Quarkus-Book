package org.elias.fascicle.quarkus.book.RecursoLibro;

import jakarta.validation.Valid;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


import org.elias.fascicle.quarkus.book.ServicioLibro.BookService;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.jboss.logging.Logger;
import jakarta.ws.rs.GET;  //para el get
import jakarta.ws.rs.Path; //para el path

import jakarta.ws.rs.Produces; //para el produces
import jakarta.ws.rs.core.MediaType;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

import java.util.List;


//import io.quarkus.security.identity.SecurityIdentity;
//import org.jboss.resteasy.annotations.cache.NoCache;
import static jakarta.ws.rs.core.Response.Status.NOT_FOUND;

@Path("/api/books")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Tag(name ="Book Endpoint")



     public class BookResource {
      @GET
      @Path("/ping")
      @Produces(MediaType.TEXT_PLAIN)
        public static String pingBook() {
        return "ping";
        }

    @Inject
    BookService service;

    @Inject
    BookMapper bookMapper;
    private static final Logger LOGGER = Logger.getLogger(BookResource.class);


    //----------------------| Documentación API |----------------------
    @Operation(summary = "Returns a random book")
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BookDTO.class)))
    //----------------------| Metrics |----------------------
    @Counted(name = "countGetRandomBook", description = "Counts how many times the GetRandomBook " +
            "method has been invoked")
    @Timed(name = "timeGetRandomBook", description = "Times how long it takes to invoke the " +
            "GetRandomBook method", unit = MetricUnits.MILLISECONDS)
    //----------------------| Peticion GET -> retorna un libro aleatorio |---------------------


    @GET
    @Path("/random")
    ////////////////////////////////////////////////Encontrar libro aleatorio//////////////////////////////////////////
    public Response getRandomBook()  {

        BookDTO bookDto = service.findRandomBook();

        LOGGER.debug("Encontre un libroDTO random " + bookDto);
        return Response.ok(bookDto).build(); //devuelve el  BookDTO en la respuesta
    }
    ////////////////////////////////////////////////Encontrar libro aleatorio//////////////////////////////////////////

    //----------------------| Documentación API |----------------------
    @Operation(summary = "Returns all the books from the database")
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType
            .APPLICATION_JSON, schema = @Schema(implementation =BookDTO.class, type = SchemaType
            .ARRAY)))
    @APIResponse(responseCode = "204", description = "No books")
    //----------------------| Metrics |----------------------
    @Counted(name = "countGetAllBooks", description = "Counts how many times the GetAllBooks " +
            "method has been invoked")
    @Timed(name = "timeGetAllBooks", description = "Times how long it takes to invoke the " +
            "GetAllBooks method", unit = MetricUnits.MILLISECONDS)
    //----------------------| Peticion GET -> retorna todos los libros |------------

    ////////////////////////////////////////////////GET BOOK//////////////////////////////////////////
            @GET
            @Path("/{id}")
            public Response getBook(@Parameter(description = "Book identifier", required = true)
                                    @PathParam("id")
                                    Long id){
                BookDTO optionalBookDTO = service.findBookById(id);
                if (optionalBookDTO!= null) {
                    LOGGER.debug("Found book " + optionalBookDTO.getTitle());
                    return Response.ok(optionalBookDTO).build();
                }else{
                    LOGGER.debug("No book found with id " + id);
                    return Response.status(NOT_FOUND).build();
                }
            }
    ////////////////////////////////////////////////GET BOOK//////////////////////////////////////////


    @Operation(summary = "Creates a new book")
    @APIResponse(responseCode = "201", description = "The URI of the created book",
            content = @Content(mediaType = MediaType.APPLICATION_JSON,
                    schema = @Schema(implementation = BookDTO.class)))
    @POST
    public Response createBook(@Valid BookDTO bookDTO, @Context UriInfo uriInfo) {

        BookDTO createdBookDTO = service.persistBook(bookDTO);

        UriBuilder builder = uriInfo.getAbsolutePathBuilder().path(Long.toString(createdBookDTO.getId()));
        LOGGER.debug("New book created with URI " + builder.build().toString());

        return Response.created(builder.build()).entity(createdBookDTO).build();
    }
//el dto que recibo puede no ser el mismo que devuelvo
    //los autores pueden ser mas de uno

    /*
    public Response createBook(@Valid BookDTO bookDTO, @Context UriInfo uriInfo) {



        bookDTO = service.persistBook(bookDTO);


        UriBuilder builder = uriInfo.getAbsolutePathBuilder().path(Long.toString(bookDTO.getId()));
        LOGGER.debug("New book created with URI " + builder.build().toString());


        return Response.created(builder.build()).build();
    }
*/

    ////////////////////////////////////////////////UPDATE BOOK//////////////////////////////////////////

    @Operation(summary = "Updates an existing book")
    @APIResponse(responseCode = "200", description = "The updated book", content = @Content(mediaType = MediaType.APPLICATION_JSON))
    @Counted(name = "countUpdateBook", description = "Counts how many times the updateBook method has been invoked")
    @Timed(name = "timeUpdateBook", description = "Times how long it takes to invoke the updateBook method", unit = MetricUnits.MILLISECONDS)
    @PUT
    @Path("/{id}")
    public Response updateBook(@PathParam("id") Long id, @Valid BookDTO bookDTO) {
        //



        BookDTO updatedBook = service.updateBook(bookDTO);

        LOGGER.debug("Book updated with new values: " + updatedBook);

        return Response.ok(updatedBook).build();
    }






    ////////////////////////////////////////////////GET ALL BOOKS//////////////////////////////////////////

    @Operation(summary = "Returns all the books from the database") // Descripción para la documentación de OpenAPI
          @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BookDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
           @APIResponse(responseCode = "204", description = "No books") // Respuesta cuando no hay libros
           @GET
          public Response getAllBooks() {
            List<BookDTO> booksDTO = service.findAllBooks(); // Llama al servicio para obtener todos los libros
            LOGGER.debug("Total number of books " + booksDTO); // Registra el evento en los logs
            return Response.ok(booksDTO).build(); // Retorna la lista de libros en la respuesta
           }

    ////////////////////////////////////////////////GET ALL BOOKS//////////////////////////////////////////



    @Operation(summary = "Returns all the books from a specific author")
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BookDTO.class, type = SchemaType.ARRAY)))
    @APIResponse(responseCode = "204", description = "No books found")
    @GET
    @Path("/by-author/{authorId}")
    public Response findBooksByAuthor(@PathParam("authorId") Long authorId) {
        List<BookDTO> booksDTO = service.findBooksByAuthor(authorId); // Llama al servicio para obtener los libros del autor
        if (booksDTO.isEmpty()) {
            return Response.noContent().build();
        }
        return Response.ok(booksDTO).build(); // Retorna la lista de libros en la respuesta
    }

    @Operation(summary = "Returns all the books with the  author")
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BookDTO.class, type = SchemaType.ARRAY)))
    @APIResponse(responseCode = "204", description = "No books found")
    @GET
    @Path("/books-author")
    public Response findAllBooksAuthors() {
        List<BookDTO> booksDTO = service.findAllBooksWithAuthor(); // Llama al servicio para obtener los libros del autor
        if (booksDTO.isEmpty()) {
            return Response.noContent().build();
        }
        return Response.ok(booksDTO).build(); // Retorna la lista de libros en la respuesta
    }





    @Operation(summary = "Deletes an existing book") // Descripción para la documentación de OpenAPI
                @APIResponse(responseCode = "204", description = "The book has been successfully deleted") // Respuesta esperada
                @DELETE
                @Path("/{id}")
                public Response deleteBook(@Parameter(description = "Book identifier", required = true) @PathParam("id") Long id) {
                    service.deleteBook(id);
                    LOGGER.debug("Book deleted with " + id);
                    return Response.noContent().build();
                }


    @Operation(summary = "Returns all the books whose average score exceeds that sent by parameter")
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BookDTO.class, type = SchemaType.ARRAY)))
    @APIResponse(responseCode = "204", description = "No books found")
    @GET
    @Path("/average-score")
    public Response averageScore (@QueryParam("rank") int rank) { //parametro de consulta

        List<BookDTO> BookDTO = service.AverageScore(rank); // Llama al servicio para obtener los libros del autor
        if ( BookDTO.isEmpty()) {
            return Response.noContent().build();
        }
        return Response.ok(BookDTO).build(); // Retorna la lista de libros en la respuesta
    }


    @Operation(summary = "Returns all books of 1 category, if it has subcategories it includes them")
    @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = BookDTO.class, type = SchemaType.ARRAY)))
    @APIResponse(responseCode = "204", description = "No books found")
    @GET
    @Path("/Books-By-Category-Including-Subcategories")
    public Response BooksByCategoryIncludingSubcategories (@QueryParam("categoryId") Long categoryId) { //parametro de consulta

        List<BookDTO> BookDTO = service.getBooksByCategoryIncludingSubcategories(categoryId); // Llama al servicio para obtener los libros del autor
        if ( BookDTO.isEmpty()) {
            return Response.noContent().build();
        }
        return Response.ok(BookDTO).build(); // Retorna la lista de libros en la respuesta
    }





     }



