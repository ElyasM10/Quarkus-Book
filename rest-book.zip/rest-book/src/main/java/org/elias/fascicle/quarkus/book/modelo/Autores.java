package org.elias.fascicle.quarkus.book.modelo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import jakarta.persistence.*;
import org.wildfly.common.annotation.NotNull;


import java.util.List;

@Schema(description = "Representacion de entidad Autores")
@Entity
public class Autores {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @NotNull //indica que no puede ser nulo
    @Schema(required = true,description = "Nombre del autor ")
    public String nombre;

    @NotNull //indica que no puede ser nulo
    @Column(name = "Apellido")
    public String apellido;

    @Column(name = "Nacionalidad")
    public String nacionalidad;

    @ManyToMany(mappedBy = "autores")
    private List<Book> listaLibros;


    //getter y setters


    public Long getId() {
        return id;
    }

    public void setListaLibros(List<Book> listaLibros) {
        this.listaLibros = listaLibros;
    }

    public List<Book> getListaLibros() {
        return listaLibros;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getApellido(){
         return  apellido;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    @Override
    public String toString() {
        return  getNombre() + " " + getApellido();
    }
}
