package org.elias.fascicle.quarkus.book.ServicioLibro;



import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.elias.fascicle.quarkus.book.AccesoLibro.AuthorsRepository;
import org.elias.fascicle.quarkus.book.AccesoLibro.CategoriaRepository;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.CategoriasDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.AutorMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.BookMapper;
import org.elias.fascicle.quarkus.book.TransformadorLibro.CategoriaMapper;

import java.io.FileNotFoundException;
import java.util.List;

import static jakarta.ws.rs.core.Response.Status.NOT_FOUND;

@ApplicationScoped
public class CategoryService {

    @Inject
    CategoriaRepository repository;




    //Persists a given book
    public CategoriasDTO persistCategory(CategoriasDTO categoryDTO) {
        return CategoriaMapper.INSTANCE.categoriaAcategoriasDTO(repository.persistCategory(CategoriaMapper.INSTANCE.toEntity(categoryDTO)));
    }



    @Fallback(fallbackMethod = "fallbackPersistCategory")
    // Método de fallback

    public CategoriasDTO fallbackPersistCategory(CategoriasDTO categoriasDTO) throws FileNotFoundException {
        return CategoriaMapper.INSTANCE.categoriaAcategoriasDTO(repository.fallbackPersistCategory(CategoriaMapper.INSTANCE.toEntity(categoriasDTO)));
    }





    @Transactional(Transactional.TxType.SUPPORTS)
    public List<CategoriasDTO> findAllCategory() {
        // Obtener todos los libros desde el repositorio
        return CategoriaMapper.INSTANCE.toCategoyDTOList(repository.findAllCategory());
    }


    @Transactional(Transactional.TxType.SUPPORTS)
    //Finds the book by his id
    public CategoriasDTO findCategoryById(Long id) {
        return CategoriaMapper.INSTANCE.categoriaAcategoriasDTO(repository.findCategoryById(id));
    }


    @Transactional(Transactional.TxType.REQUIRED)
    public CategoriasDTO updateCategory(CategoriasDTO categoryDTO) {

        return CategoriaMapper.INSTANCE.categoriaAcategoriasDTO(repository.updateCategory(CategoriaMapper.INSTANCE.toEntity(categoryDTO)));
    }




    public void deleteCategory(Long id) {
        repository.deleteCategory(id);
    }


}

