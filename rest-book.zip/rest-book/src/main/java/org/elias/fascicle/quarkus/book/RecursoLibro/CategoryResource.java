package org.elias.fascicle.quarkus.book.RecursoLibro;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.metrics.MetricUnits;
import org.eclipse.microprofile.metrics.annotation.Counted;
import org.eclipse.microprofile.metrics.annotation.Timed;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.elias.fascicle.quarkus.book.ServicioLibro.CategoryService;
import org.elias.fascicle.quarkus.book.TransferibleLibro.AutorDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.CategoriasDTO;
import org.elias.fascicle.quarkus.book.TransformadorLibro.CategoriaMapper;
import org.jboss.logging.Logger;

import java.util.List;

import static jakarta.ws.rs.core.Response.Status.NOT_FOUND;


@Path("/api/categorias")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name ="Categorias Endpoint")

@ApplicationScoped
public class CategoryResource {




    /*
        @GET
        @Path("/ping")
        @Produces(MediaType.TEXT_PLAIN)
        public static String pingBook() {
            return "ping";
        }
*/

        @Inject
        CategoryService service;

        @Inject
        CategoriaMapper categoriaMapper;
        private static final Logger LOGGER = Logger.getLogger(org.elias.fascicle.quarkus.book.RecursoLibro.CategoryResource.class);


        @Operation(summary = "Creates a new Author")
        @APIResponse(responseCode = "201", description = "The URI of the created author",
                content = @Content(mediaType = MediaType.APPLICATION_JSON,
                        schema = @Schema(implementation = AutorDTO.class)))
        @POST
        public Response createCategory(@Valid CategoriasDTO categoriasDTO, @Context UriInfo uriInfo) {


            categoriasDTO= service.persistCategory(categoriasDTO);


            UriBuilder builder = uriInfo.getAbsolutePathBuilder().path(Long.toString(categoriasDTO.getId()));
            LOGGER.debug("New category created with URI " + builder.build().toString());


            return Response.created(builder.build()).build();
        }




        @Operation(summary = "Returns all the category from the database") // Descripción para la documentación de OpenAPI
        @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = CategoriasDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
        @APIResponse(responseCode = "204", description = "No Authors") // Respuesta cuando no hay libros
        @GET
        public Response getAllAuthors() {
            List<CategoriasDTO>  categoriasDTO = service.findAllCategory(); // Llama al servicio para obtener todos los libros
            LOGGER.debug("Total number of category " +  categoriasDTO); // Registra el evento en los logs
            return Response.ok( categoriasDTO).build(); // Retorna la lista de libros en la respuesta
        }


        @GET
        @Operation(summary = "Returns categoy by a determinate  id") // Descripción para la documentación de OpenAPI
        @APIResponse(responseCode = "200", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = CategoriasDTO.class, type = SchemaType.ARRAY))) // Respuesta esperada
        @APIResponse(responseCode = "204", description = "No categorys by that id found") // Respuesta cuando no hay libros
        @Path("/{id}")
        public Response getCategorybyId(@Parameter(description = "Category identifier", required = true)
                                      @PathParam("id")
                                      Long id){
            CategoriasDTO  categoriasDTO = service.findCategoryById(id);
            if ( categoriasDTO!= null) {
                LOGGER.debug("Found category" +  categoriasDTO.getNombre());
                return Response.ok( categoriasDTO).build();
            }else{
                LOGGER.debug("No category found with id " + id);
                return Response.status(NOT_FOUND).build();
            }
        }




        ////////////////////////////////////////////////UPDATE BOOK//////////////////////////////////////////

        @Operation(summary = "Updates an existing category")
        @APIResponse(responseCode = "200", description = "The updated categoy", content = @Content(mediaType = MediaType.APPLICATION_JSON))
        @Counted(name = "countUpdateCategory", description = "Counts how many times the updateCategorys method has been invoked")
        @Timed(name = "timeUpdateCategorys", description = "Times how long it takes to invoke the updateCategorys method", unit = MetricUnits.MILLISECONDS)
        @PUT
        @Path("/{id}")
        public Response updateCategory(@PathParam("id") Long id, @Valid CategoriasDTO  categoriasDTO) {
            //

            CategoriasDTO updatedCategory = service.updateCategory( categoriasDTO);

            LOGGER.debug("Author updated with new values: " + updatedCategory);

            return Response.ok(updatedCategory ).build();
        }









        @Operation(summary = "Deletes an existing category") // Descripción para la documentación de OpenAPI
        @APIResponse(responseCode = "204", description = "The Category has been successfully deleted") // Respuesta esperada
        @DELETE
        @Path("/{id}")
        public Response deleteCategory (@Parameter(description = "Category identifier", required = true) @PathParam("id") Long id) {
            service.deleteCategory(id);
            LOGGER.debug("Category deleted with " + id);
            return Response.noContent().build();
        }

}


