package org.elias.fascicle.quarkus.book.TransformadorLibro;

import org.elias.fascicle.quarkus.book.TransferibleLibro.CategoriasDTO;
import org.elias.fascicle.quarkus.book.TransferibleLibro.ComentariosDTO;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.elias.fascicle.quarkus.book.modelo.Comentarios;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface CommentaryMapper {

    CommentaryMapper INSTANCE = Mappers.getMapper(CommentaryMapper.class);

    @Mapping(source = "email", target = "email")
    @Mapping(source ="texto",target="texto")
    @Mapping(source ="puntuacion",target="puntuacion")
    //@Mapping(source ="id",target="id")


    ComentariosDTO comentariosAcomentariosDTO(Comentarios comentariosDTO);


    //DTO a entidad
    @InheritInverseConfiguration
    Comentarios toEntity(ComentariosDTO comentariosDTO);

    //Listas de DTOs a listas de Entidades
    List<ComentariosDTO> toCommentaryDTOList(List<Comentarios> comeentariosList);

    //Listas de Entidades a listas de DTOs
    List<Comentarios> toEntityList(List<ComentariosDTO> transferibleCateroryList);

}
