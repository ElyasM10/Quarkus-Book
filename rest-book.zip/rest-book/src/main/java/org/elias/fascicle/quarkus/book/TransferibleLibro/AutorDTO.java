package org.elias.fascicle.quarkus.book.TransferibleLibro;


import org.elias.fascicle.quarkus.book.modelo.Book;


import java.util.List;


public class AutorDTO {


    private Long id;
    public String nombre;
    public String apellido;
    public String nacionalidad;
    public List<Book> listaLibros;




    //getter y setters


    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setListaLibros(List<Book> listaLibros) {
        this.listaLibros = listaLibros;
    }

    public List<Book> getListaLibros() {
        return listaLibros;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getApellido(){
        return  apellido;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

}