package org.elias.fascicle.quarkus.book.TransformadorLibro;

import jakarta.inject.Named;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import org.elias.fascicle.quarkus.book.TransferibleLibro.BookDTO;
import org.elias.fascicle.quarkus.book.modelo.Autores;
import org.elias.fascicle.quarkus.book.modelo.Book;
import org.elias.fascicle.quarkus.book.modelo.Categorias;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.wildfly.common.annotation.NotNull;

import java.math.BigDecimal;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Mapper
public interface BookMapper {

    BookMapper INSTANCE = Mappers.getMapper(BookMapper.class);

    @InheritInverseConfiguration
    Book toEntity(BookDTO bookDTO);

    @Mapping(source = "title", target = "title")
    @Mapping(source = "isbn13", target = "isbn13")
     @Mapping(source = "isbn10", target = "isbn10")
  //  @Mapping(source = "author", target = "author")
    @Mapping(source = "yearOfPublication", target = "yearOfPublication")
    @Mapping(source = "nbOfPages", target = "nbOfPages")
    @Mapping(source = "rank", target = "rank")
    @Mapping(source = "price", target = "price")
    @Mapping(source = "smallImageUrl", target = "smallImageUrl")
    @Mapping(source = "mediumImageUrl", target = "mediumImageUrl")
    @Mapping(source = "description", target = "description")
    @Mapping(source ="id",target="id")
    @Mapping(source = "categoria.nombre", target = "categoriaNombre")
    @Mapping(source = "autores", target = "autoresString")
    @Mapping(source = "categoria.id",target = "id_categoria")
 //  @Mapping(source = "autores",target = "autores")
  //  @Mapping(source = "autorBook.id",target = "id_autor")



        // @Mapping(source = "categoria",target="categoria")
 //  @Mapping(source = "categoria.subCategoriaNombre", target = "subcategoriaNombre")


    BookDTO LibroAlibroDTO(Book book);




    // Convertir lista de Autores a lista de Strings
    default List<String> mapAutoresAstrings(List<Autores> autores) {
        if (autores == null) {
            return null;
        }
        return autores.stream()
                .map(Autores::toString)
                .collect(Collectors.toList());
    }

    // Convertir lista de Strings a lista de Autores

    default List<Autores> mapStringsToAutores(List<String> autoresStrings) {
        if (autoresStrings == null) {
            return null;
        }
        return autoresStrings.stream()
                .map(this::convertStringToAutor)
                .collect(Collectors.toList());
    }

    // Método para convertir String a Autores
    default Autores convertStringToAutor(String autorString) {
        Autores autor = new Autores();

        String[] partes = autorString.split(" ");
        if (partes.length > 1) {
            autor.setNombre(partes[0]); // Nombre
            autor.setApellido(partes[1]); // Apellido
        } else {
            autor.setNombre(autorString); // Solo nombre
        }
        return autor;
    }





    //DTO a entidad



    //Listas de DTOs a listas de Entidades
    List<BookDTO> toLibroDTOList(List<Book> bookList);

    //Listas de Entidades a listas de DTOs
    List<Book> toEntityList(List<BookDTO> transferibleLibroList);


}



// Book toEntity(BookDTO bookDTO);
