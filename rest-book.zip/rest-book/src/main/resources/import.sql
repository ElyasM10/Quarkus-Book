

INSERT INTO Categorias(id, nombre)
VALUES
(1, 'Horror'),
(2, 'Ciencia Ficcion'),
(3, 'Fantasia');

--ALTER TABLE categorias ADD COLUMN subcategoria_nombre VARCHAR(255);

INSERT INTO Categorias(id, subCategoriaNombre, id_padre)
VALUES
    (4, 'Terror Psicológico', 1), -- Subcategoría de Horror
    (5, 'Ciencia Ficción Espacial', 2), -- Subcategoría de Ciencia Ficcion
    (6, 'Fantasia Épica', 3); -- Subcategoría de Fantasia
SELECT setval('Categorias_id_seq',6);

INSERT INTO Autores(id, nombre, apellido, nacionalidad) VALUES (100, 'Stephen', 'King', 'USA');
INSERT INTO Autores(id, nombre, apellido, nacionalidad) VALUES (101, 'Isaac', 'Asimov', 'USA');
INSERT INTO Autores(id, nombre, apellido, nacionalidad) VALUES (102, 'J.K.', 'Rowling', 'UK');
INSERT INTO Autores(id, nombre, apellido, nacionalidad) VALUES (103, 'Arthur', 'Clarke', 'UK');
SELECT setval('Autores_id_seq',103);

INSERT INTO Book(id, title, isbn_13, isbn_10, year_of_publication, nb_of_pages, rank, price, small_image_url, medium_image_url, description, id_categoria)
VALUES
(1, 'It', '9780450411434', '0450411435', 1986, 1138, 9, 19.99, 'http://example.com/small/it.jpg', 'http://example.com/medium/it.jpg', 'A horror novel.', 1),
(2, '2001: A Space Odyssey', '9780451457999', '0451457994', 1968, 297, 9, 15.99, 'http://example.com/small/2001.jpg', 'http://example.com/medium/2001.jpg', 'A science fiction novel.', 3),
(3, 'The Shining', '9780385121675', '0385121676', 1977, 447, 10, 25.99, 'http://example.com/small/shining.jpg', 'http://example.com/medium/shining.jpg', 'A psychological horror novel.', 1),
(4, 'Misery', '9780451169525', '0451169526', 1987, 310, 8, 22.99, 'http://example.com/small/misery.jpg', 'http://example.com/medium/misery.jpg', 'A thriller about a novelist held captive by an obsessed fan.', 1),
(5, 'Harry Potter y la piedra filosofal', '9780439554930', '0439554934', 1997, 309, 10, 20.99, 'http://example.com/small/harry_potter_1.jpg', 'http://example.com/medium/harry_potter_1.jpg', 'A young wizard begins his journey at Hogwarts School of Witchcraft and Wizardry.', 3);
SELECT setval('Book_id_seq',5);

INSERT INTO Autores_Libros(libro_id, autor_id)
VALUES
(1, 100),  -- 'It' escrito por Stephen King
(2, 103),  -- '2001: A Space Odyssey' escrito por Arthur Clarke
(3,100), --shining por Stephem king
(4,100),
(5,102); --hp JK

--INSERT INTO Comentarios(id, puntuacion, email, texto, libro_id)
--VALUES
--(100, 10, 'kevin@gmail.com', 'Muy Bueno', 1),
--(101, 8, 'lisa@gmail.com', 'Interesante', 2);

--SELECT * FROM Autores;
--SELECT * FROM Categorias;
--SELECT * FROM Book;
--SELECT * FROM Autores_Libros;


--SELECT * FROM Comentarios;



